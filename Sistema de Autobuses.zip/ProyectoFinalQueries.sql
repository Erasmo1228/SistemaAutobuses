CREATE DATABASE SistemaAutobuses;
GO

USE SistemaAutobuses;
GO

CREATE TABLE Usuarios
(
    IdUsuario INT IDENTITY(1,1) PRIMARY KEY,

    Usuario VARCHAR(50) NOT NULL UNIQUE,

    Clave VARCHAR(255) NOT NULL,

    Rol VARCHAR(20) NOT NULL
    CHECK(Rol IN('Administrador','Usuario')),

    Estado BIT NOT NULL DEFAULT 1
);
GO
CREATE TABLE Choferes
(
    IdChofer INT IDENTITY(1,1) PRIMARY KEY,

    Nombre VARCHAR(80) NOT NULL,

    Apellido VARCHAR(80) NOT NULL,

    Cedula VARCHAR(20) NOT NULL UNIQUE,

    FechaNacimiento DATE NOT NULL,

    Disponible BIT NOT NULL DEFAULT 1,

    Estado BIT NOT NULL DEFAULT 1
);
GO

CREATE TABLE Autobuses
(
    IdAutobus INT IDENTITY(1,1) PRIMARY KEY,

    Marca VARCHAR(50) NOT NULL,

    Modelo VARCHAR(50) NOT NULL,

    Placa VARCHAR(20) NOT NULL UNIQUE,

    Color VARCHAR(30),

    Anio INT,

    Disponible BIT NOT NULL DEFAULT 1,

    Estado BIT NOT NULL DEFAULT 1
);
GO
CREATE TABLE Rutas
(
    IdRuta INT IDENTITY(1,1) PRIMARY KEY,

    NombreRuta VARCHAR(100) NOT NULL UNIQUE,

    Disponible BIT NOT NULL DEFAULT 1,

    Estado BIT NOT NULL DEFAULT 1
);
GO
CREATE TABLE Asignaciones
(
    IdAsignacion INT IDENTITY(1,1) PRIMARY KEY,

    IdChofer INT NOT NULL,

    IdAutobus INT NOT NULL,

    IdRuta INT NOT NULL,

    FechaAsignacion DATETIME NOT NULL DEFAULT GETDATE(),

    Estado VARCHAR(20)
    CHECK(Estado IN('Activa','Finalizada')),

    CONSTRAINT FK_Chofer
        FOREIGN KEY(IdChofer)
        REFERENCES Choferes(IdChofer),

    CONSTRAINT FK_Autobus
        FOREIGN KEY(IdAutobus)
        REFERENCES Autobuses(IdAutobus),

    CONSTRAINT FK_Ruta
        FOREIGN KEY(IdRuta)
        REFERENCES Rutas(IdRuta)
);
GO

--Procedimientos almacenados
--Procedure para el login
CREATE PROC sp_Login

@Usuario VARCHAR(50),
@Clave VARCHAR(255)

AS
BEGIN

SELECT *

FROM Usuarios

WHERE Usuario=@Usuario

AND Clave=@Clave

AND Estado=1;

END
GO
--Procedures para el modulo Choferes
CREATE PROC sp_InsertarChofer

@Nombre VARCHAR(80),
@Apellido VARCHAR(80),
@Cedula VARCHAR(20),
@FechaNacimiento DATE

AS
BEGIN

INSERT INTO Choferes
(
Nombre,
Apellido,
Cedula,
FechaNacimiento
)

VALUES
(
@Nombre,
@Apellido,
@Cedula,
@FechaNacimiento
);

END
GO

CREATE PROC sp_ModificarChofer

@IdChofer INT,
@Nombre VARCHAR(80),
@Apellido VARCHAR(80),
@Cedula VARCHAR(20),
@FechaNacimiento DATE

AS
BEGIN

UPDATE Choferes

SET

Nombre=@Nombre,
Apellido=@Apellido,
Cedula=@Cedula,
FechaNacimiento=@FechaNacimiento

WHERE IdChofer=@IdChofer;

END
GO

CREATE PROC sp_EliminarChofer

@IdChofer INT

AS
BEGIN

UPDATE Choferes

SET Estado=0

WHERE IdChofer=@IdChofer;

END
GO

CREATE PROC sp_ListarChoferes
AS
BEGIN

SELECT *

FROM Choferes

WHERE Estado=1;

END
GO

CREATE PROC sp_BuscarChofer

@Texto VARCHAR(80)

AS
BEGIN

SELECT *

FROM Choferes

WHERE Estado=1

AND
(
Nombre LIKE '%'+@Texto+'%'

OR

Apellido LIKE '%'+@Texto+'%'

OR

Cedula LIKE '%'+@Texto+'%'
);

END
GO
--Procedure para el module Autobus
CREATE PROC sp_InsertarAutobus

@Marca VARCHAR(50),
@Modelo VARCHAR(50),
@Placa VARCHAR(20),
@Color VARCHAR(30),
@Anio INT

AS
BEGIN

INSERT INTO Autobuses

(
Marca,
Modelo,
Placa,
Color,
Anio
)

VALUES
(
@Marca,
@Modelo,
@Placa,
@Color,
@Anio
);

END
GO

CREATE PROC sp_ModificarAutobus

@IdAutobus INT,
@Marca VARCHAR(50),
@Modelo VARCHAR(50),
@Placa VARCHAR(20),
@Color VARCHAR(30),
@Anio INT

AS
BEGIN

UPDATE Autobuses

SET

Marca=@Marca,
Modelo=@Modelo,
Placa=@Placa,
Color=@Color,
Anio=@Anio

WHERE IdAutobus=@IdAutobus;

END
GO

CREATE PROC sp_EliminarAutobus

@IdAutobus INT

AS
BEGIN

UPDATE Autobuses

SET Estado=0

WHERE IdAutobus=@IdAutobus;

END
GO

CREATE PROC sp_ListarAutobuses

AS
BEGIN

SELECT *

FROM Autobuses

WHERE Estado=1;

END
GO
CREATE PROC sp_BuscarAutobus

@Texto VARCHAR(100)

AS
BEGIN

    SELECT
        IdAutobus,
        Marca,
        Modelo,
        Placa,
        Color,
        Anio,
        Disponible,
        Estado
    FROM Autobuses
    WHERE Estado = 1
    AND
    (
        Marca LIKE '%' + @Texto + '%'
        OR Modelo LIKE '%' + @Texto + '%'
        OR Placa LIKE '%' + @Texto + '%'
        OR Color LIKE '%' + @Texto + '%'
    )
    ORDER BY Marca, Modelo;

END
GO

--Procedure para el modulo Rutas

CREATE PROC sp_InsertarRuta

@NombreRuta VARCHAR(100)

AS
BEGIN

    INSERT INTO Rutas
    (
        NombreRuta
    )
    VALUES
    (
        @NombreRuta
    );

END
GO

CREATE PROC sp_ModificarRuta

@IdRuta INT,
@NombreRuta VARCHAR(100)

AS
BEGIN

    UPDATE Rutas
    SET
        NombreRuta = @NombreRuta
    WHERE IdRuta = @IdRuta;

END
GO
CREATE PROC sp_EliminarRuta

@IdRuta INT

AS
BEGIN

    UPDATE Rutas
    SET Estado = 0
    WHERE IdRuta = @IdRuta;

END
GO

CREATE PROC sp_ListarRutas

AS
BEGIN

    SELECT
        IdRuta,
        NombreRuta,
        Disponible,
        Estado
    FROM Rutas
    WHERE Estado = 1
    ORDER BY NombreRuta;

END
GO
CREATE PROC sp_BuscarRuta

@Texto VARCHAR(100)

AS
BEGIN

    SELECT
        IdRuta,
        NombreRuta,
        Disponible,
        Estado
    FROM Rutas
    WHERE Estado = 1
    AND NombreRuta LIKE '%' + @Texto + '%'
    ORDER BY NombreRuta;

END
GO
--Procedure del modulo Disponibilidad
CREATE PROC sp_ChoferesDisponibles

AS
BEGIN

SELECT

IdChofer,
Nombre+' '+Apellido AS NombreCompleto

FROM Choferes

WHERE Disponible=1

AND Estado=1;

END
GO
CREATE PROC sp_AutobusesDisponibles

AS
BEGIN

SELECT

IdAutobus,
Marca+' '+Modelo+' - '+Placa AS Autobus

FROM Autobuses

WHERE Disponible=1

AND Estado=1;

END
GO
CREATE PROC sp_RutasDisponibles

AS
BEGIN

SELECT *

FROM Rutas

WHERE Disponible=1

AND Estado=1;

END
GO

--Procedure del Modulo asignacion
CREATE PROC sp_InsertarAsignacion

@IdChofer INT,
@IdAutobus INT,
@IdRuta INT

AS
BEGIN

BEGIN TRANSACTION;

INSERT INTO Asignaciones
(
IdChofer,
IdAutobus,
IdRuta,
Estado
)

VALUES
(
@IdChofer,
@IdAutobus,
@IdRuta,
'Activa'
);

UPDATE Choferes
SET Disponible=0
WHERE IdChofer=@IdChofer;

UPDATE Autobuses
SET Disponible=0
WHERE IdAutobus=@IdAutobus;

UPDATE Rutas
SET Disponible=0
WHERE IdRuta=@IdRuta;

COMMIT TRANSACTION;

END
GO

CREATE PROC sp_FinalizarAsignacion

@IdAsignacion INT

AS
BEGIN

DECLARE

@IdChofer INT,
@IdAutobus INT,
@IdRuta INT;

SELECT

@IdChofer=IdChofer,
@IdAutobus=IdAutobus,
@IdRuta=IdRuta

FROM Asignaciones

WHERE IdAsignacion=@IdAsignacion;

UPDATE Asignaciones

SET Estado='Finalizada'

WHERE IdAsignacion=@IdAsignacion;

UPDATE Choferes
SET Disponible=1
WHERE IdChofer=@IdChofer;

UPDATE Autobuses
SET Disponible=1
WHERE IdAutobus=@IdAutobus;

UPDATE Rutas
SET Disponible=1
WHERE IdRuta=@IdRuta;

END
GO
CREATE PROCEDURE sp_ListarAsignaciones
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        A.IdAsignacion,

        C.Nombre + ' ' + C.Apellido AS Chofer,

        AB.Marca + ' ' + AB.Modelo + ' - ' + AB.Placa AS Autobus,

        R.NombreRuta AS Ruta,

        A.FechaAsignacion,

        A.Estado

    FROM Asignaciones A

    INNER JOIN Choferes C
        ON A.IdChofer = C.IdChofer

    INNER JOIN Autobuses AB
        ON A.IdAutobus = AB.IdAutobus

    INNER JOIN Rutas R
        ON A.IdRuta = R.IdRuta

    ORDER BY A.IdAsignacion DESC;
END
GO